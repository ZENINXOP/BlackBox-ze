package black.android.content;


import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BConstructor;

@BClassName("android.content.SyncAdapterType")
public interface SyncAdapterType {
    @BConstructor
    SyncAdapterType _new(String String0, String String1, boolean boolean2, boolean boolean3, boolean boolean4, boolean boolean5, String String6);
}
