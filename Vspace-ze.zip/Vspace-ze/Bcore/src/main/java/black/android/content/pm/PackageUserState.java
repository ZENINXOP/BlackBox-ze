package black.android.content.pm;


import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BConstructor;

@BClassName("android.content.pm.PackageUserState")
public interface PackageUserState {
    @BConstructor
    PackageUserState _new();
}
