package black.com.android.internal.content;

import android.content.Intent;

import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BConstructor;

@BClassName("com.android.internal.content.ReferrerIntent")
public interface ReferrerIntent {
    @BConstructor
    Intent _new(Intent Intent0, String String1);
}
