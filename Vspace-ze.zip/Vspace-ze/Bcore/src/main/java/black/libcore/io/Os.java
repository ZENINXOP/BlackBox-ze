package black.libcore.io;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("libcore.io.Os")
public interface Os {
}
