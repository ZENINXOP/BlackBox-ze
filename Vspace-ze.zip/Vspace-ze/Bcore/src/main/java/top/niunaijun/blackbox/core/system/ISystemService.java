package top.niunaijun.blackbox.core.system;

/**
 * updated by alex5402 on 4/22/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * TFNQw5HgWUS33Ke1eNmSFTwoQySGU7XNsK (USDT TRC20)
 */
public interface ISystemService {
    void systemReady();
}
