package top.niunaijun.blackbox.fake.hook;

/**
 * updated by alex5402 on 3/30/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * TFNQw5HgWUS33Ke1eNmSFTwoQySGU7XNsK (USDT TRC20)
 */
public interface IInjectHook {
    void injectHook();

    boolean isBadEnv();
}
