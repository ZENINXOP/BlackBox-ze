//
// Created for blocking problematic resource files
//

#ifndef VIRTUALM_FILESYSTEMHOOK_H
#define VIRTUALM_FILESYSTEMHOOK_H

class FileSystemHook {
public:
    static void init();
};

#endif //VIRTUALM_FILESYSTEMHOOK_H
